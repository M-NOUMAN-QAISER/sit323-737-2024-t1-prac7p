# SIT737 Task 9.1P - MongoDB Integration

## Build and Deploy

```bash
docker build -t muhammad532/calculator-app .
docker push muhammad532/calculator-app

kubectl apply -f mongodb-secret.yaml
kubectl apply -f mongodb-pvc.yaml
kubectl apply -f mongodb-deployment.yaml
kubectl apply -f mongodb-service.yaml
kubectl apply -f app-deployment.yaml
kubectl apply -f app-service.yaml
```
